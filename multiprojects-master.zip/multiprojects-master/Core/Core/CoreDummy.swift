//
//  CoreDummy.swift
//  Core
//
//  Created by Leandro Perez on 7/26/19.
//  Copyright © 2019 Leandro Perez. All rights reserved.
//

import Foundation
import RxSwift

public class CoreDummy{
    public init(){

    }
}
