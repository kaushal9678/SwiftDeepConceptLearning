import UIKit
import Core
import RxSwift

Observable<Int>.just(2)
let duymmy = CoreDummy()
