//
//  FeatureX.h
//  FeatureX
//
//  Created by Leandro Perez on 7/26/19.
//  Copyright © 2019 Leandro Perez. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for FeatureX.
FOUNDATION_EXPORT double FeatureXVersionNumber;

//! Project version string for FeatureX.
FOUNDATION_EXPORT const unsigned char FeatureXVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FeatureX/PublicHeader.h>


