//
//  FeatureXDummy.swift
//  FeatureX
//
//  Created by Leandro Perez on 7/26/19.
//  Copyright © 2019 Leandro Perez. All rights reserved.
//

import Foundation
import Core

public class FeatureXDummy{
    public init(){
        let coreDummy = CoreDummy()
    }
}
