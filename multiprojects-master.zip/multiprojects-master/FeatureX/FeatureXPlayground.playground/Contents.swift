import UIKit
import FeatureX
import Core

var dummy = FeatureXDummy()
var coreDummy = CoreDummy()
