# multiprojects
This is a simple workspace that shows a modular architecture approach using Cocoapods to manage external dependencies.

### CocoaPods

Run `pod install` and re-open the project to compile and run.
